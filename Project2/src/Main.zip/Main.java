


public class Main {

    public static void main(String[] args){

        PokemonSelection Pokemon1 = new PokemonSelection();
        Pokemon tempPokemon1 = new Pokemon();

        PokemonSelection Pokemon2 = new PokemonSelection();
        Pokemon tempPokemon2 = new Pokemon();

        Pokemon1.assignPokemon(1, tempPokemon1);
        Pokemon2.assignPokemon(2, tempPokemon2);






    }
}
