public class JSONTest {

    public static void main(String[] args){
        JsonArrayReader reader = new JsonArrayReader();
        reader.readJSON();
        reader.display();
    }

}
